
<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Insert title here</title>
		<!-- Meta -->
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="keywords" content="SITE KEYWORDS HERE" />
		<meta name="description" content="">
		<meta name='copyright' content=''>
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<!-- Title -->
		<title>welcome</title>
		<!-- Favicon -->
		<link rel="icon" type="image/png" href="images/favicon.png">
		<!-- Web Font -->
		<link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700,900" rel="stylesheet">

		<!-- Bootstrap CSS -->
		<link rel="stylesheet" href="css/bootstrap.min.css">
		<!-- Font Awesome CSS -->
        <link rel="stylesheet" href="css/font-awesome.min.css">
		<!-- Fancy Box CSS -->
        <link rel="stylesheet" href="css/jquery.fancybox.min.css">
		<!-- Owl Carousel CSS -->
        <link rel="stylesheet" href="css/owl.carousel.min.css">
        <link rel="stylesheet" href="css/owl.theme.default.min.css">
		<!-- Animate CSS -->
        <link rel="stylesheet" href="css/animate.min.css">
		<!-- Slick Nav CSS -->
        <link rel="stylesheet" href="css/slicknav.min.css">
        <!-- Magnific Popup -->
		<link rel="stylesheet" href="css/magnific-popup.css">
		
		<!-- Learedu Stylesheet -->
        <link rel="stylesheet" href="css/normalize.css">
        <link rel="stylesheet" href="style.css">
        <link rel="stylesheet" href="css/responsive.css">
		
		<!-- Learedu Color -->
		<link rel="stylesheet" href="css/color/color1.css">
		<!--<link rel="stylesheet" href="css/color/color2.css">-->
		<!--<link rel="stylesheet" href="css/color/color3.css">-->
		<!--<link rel="stylesheet" href="css/color/color4.css">-->
		<!--<link rel="stylesheet" href="css/color/color5.css">-->
		<!--<link rel="stylesheet" href="css/color/color6.css">-->
		<!--<link rel="stylesheet" href="css/color/color7.css">-->
		<!--<link rel="stylesheet" href="css/color/color8.css">-->
		
</head>
<body>
<!-- Footer -->
	<a class="open-button" href="https://wa.me/917498807045?text=hello...."><i class="fa fa-whatsapp"></i></a>
		<section id="error-page" class="error-page overlay">
			<div id="particles-js"><canvas class="particles-js-canvas-el" width="2560" height="783" style="width: 100%; height: 100%;"></canvas></div>	
		<footer class="footer overlay section">
			<!-- Footer Top -->
			<div class="footer-top">
				<div class="container">
					<div class="row">
                    	
							<div class="col-lg-4 col-md-6 col-12">
							<!-- Latest News -->
							<div class="single-widget">
							
								<div class="header">
							<div class="logo"><a href="index.php"><img src="images/logo1.jpg" alt=""></a></div>
                            </div>
                          <a href="index.php">IIAL INTERNATIONAL INSTITUTE OF AESTHETICS AND LASER (IIAL)...Learning made Easy</a>
							</div>
							<!--/ End Latest News -->
						</div>
						<div class="col-lg-4 col-md-6 col-12">
							<!-- About -->
							<div class="single-widget about">
							
								<p>International Institute of Aesthetics and Laser imparts comprehensive professional training through courses in Facial Skin Care aesthetics, Cosmetology, Laser Treatments, Trichology.<br> We provide the training under the guidance of experienced and known professionals in the industry so that the students get to know the nitty-gritty of the work that is going to follow.
								<br>A balanced education where we focus on both theoretical and practical aspects of the course is delivered.</p>
								
							</div>
							<!--/ End About -->
						</div>
					
					
						<div class="col-lg-4 col-md-6 col-12">
							<!-- Latest News -->
							<div class="single-widget useful-links">
								<h2>Contact US</h2>
								<ul  class="list">
									<li><a href="contact.php"><i class="fa fa-map-marker"></i> 2nd Floor,Above ICICI Bank,Near Kohinoor Hotel, MG Road, Camp, Pune, Maharashtra 411001</a></li>
									<li><a href="#"><i class="fa fa-phone"></i> +91 7498807045</a></li>
									<li><a href="#"><i class="fa fa-envelope"></i> iialcourses@gmail.com</a></li>
									
								
								</ul>
							</div>
							
							<!--/ End Latest News -->
						</div>
					
					</div>
				</div>
			</div>
			<!--/ End Footer Top -->
			<!-- Footer Bottom -->
			<div class="footer-bottom">
				<div class="container">
					<div class="row">
						<div class="col-12">
							<div class="bottom-head">
								<div class="row">
									<div class="col-12">
										<!-- Social -->
										<ul class="social">
										
										
										</ul>
										<!-- End Social -->
										<!-- Copyright -->
										<div class="copyright">
											<p></p>
										</div>
										<!--/ End Copyright -->
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!--/ End Footer Bottom -->
		</footer>
		<!--/ End Footer -->
			</section>
		
		<!-- Jquery JS-->
       
		<!-- Particle JS -->
		<script src="js/particles.min.js"></script>
			<script src="js/particle-app.js"></script>	
		<!-- Fancy Box JS-->
		
		<!-- Google Maps JS -->
		
    </body>

</html>